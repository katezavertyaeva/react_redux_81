import styled from "@emotion/styled";

export const Lesson17Wrapper = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  padding: 40px;
  background-color: #afd7a7ff;
`;
